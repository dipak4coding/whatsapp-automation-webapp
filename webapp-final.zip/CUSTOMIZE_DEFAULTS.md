# Customizing Default Settings

## 📝 How to Set Your Own Default Configuration

Before distributing the application to users, you can customize the default settings so they don't need to configure everything manually.

### 1. Update Phone Numbers

Edit `default_config.json`:
```json
{
  "notification_contact1": "+919876543210",  ← Change this
  "notification_contact2": "+918765432109",  ← Change this
  "user_data_type": "shs",
  "message_delay": 5,
  "app_name": "WhatsApp Legal Notice Automation",
  "law_firm_name": "Your Law Firm Name"      ← Change this
}
```

### 2. Update Message Templates

Edit files in `default_templates/` folder:
- `active_message.txt`
- `inactive_message.txt`
- `no_instruction_message.txt`

Replace "Your Law Firm Name" with your actual firm name.

### 3. Available Placeholders in Templates

You can use these placeholders in your message templates:
- `{Client}` - Client name
- `{Contact}` - Phone number
- `{NextHearingDate}` - Hearing date
- `{Category}` - Client category
- `{TypRnRy}` - Case type
- `{Parties}` - Party names

### 4. Regenerate Package

After making changes:
1. Run `./create_deployment_package.sh` again
2. Share the new `WhatsApp-Automation-Windows.zip` file

### 5. Template Example

Here's a professional template example:

```
Dear {Client},

Greetings from ABC Legal Associates!

This is to inform you that your case "{Parties}" has a scheduled hearing on {NextHearingDate}.

Case Details:
- Type: {TypRnRy}
- Category: {Category}
- Date: {NextHearingDate}

Please ensure:
✓ Arrive 30 minutes early
✓ Bring all required documents
✓ Contact us if you cannot attend

For any queries, call us at +91-XXXX-XXXX-XX

Best regards,
ABC Legal Associates
www.abclegal.com
```

### 6. Advanced Customization

To change the application branding:
1. Edit `templates/base.html` - Change the navbar title
2. Edit `app.py` - Update the `app_name` variable
3. Modify the window title in batch files

### 7. Testing Your Defaults

1. Delete existing `config.json` and `templates/` folder
2. Run `python app.py`
3. Check if your defaults load correctly
4. Test the configuration page

This ensures users get your customized defaults automatically!