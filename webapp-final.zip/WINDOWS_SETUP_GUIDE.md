# WhatsApp Message Automation - Windows Setup Guide

## 📋 Prerequisites

### Required Software:
1. **Python 3.8 or newer**
   - Download from: https://www.python.org/downloads/
   - ✅ **IMPORTANT**: Check "Add Python to PATH" during installation
   - ✅ **IMPORTANT**: Select "Install for all users"

2. **Google Chrome Browser**
   - Download from: https://www.google.com/chrome/
   - Required for WhatsApp Web automation

### System Requirements:
- Windows 10 or Windows 11
- Internet connection
- At least 2GB free disk space

## 🚀 Quick Start (First Time Setup)

### Step 1: Extract Files
1. Extract the WhatsApp-Automation.zip file to a folder (e.g., `C:\WhatsApp-Automation`)
2. Open the extracted folder

### Step 2: Run First-Time Setup
1. Right-click on `install_windows.bat`
2. Select "Run as administrator" (recommended)
3. Follow the on-screen instructions
4. Wait for all packages to install (this may take 5-10 minutes)

### Step 3: Start the Application
1. Double-click `start_windows.bat`
2. Wait for the application to start
3. Open your web browser and go to: `http://localhost:8080`

## 💻 Using the Application

### Initial Configuration:
1. **Upload CSV File**: Upload your client data CSV file
2. **Configure Templates**: Go to Configuration page to set up message templates
3. **Set Notification Numbers**: Add your notification phone numbers

### CSV File Format:
Your CSV file must contain these columns:
- `Client`: Client name
- `Contact`: Phone number with country code (e.g., +919876543210)
- `NextHearingDate`: Date in YYYY-MM-DD format
- `Category`: Active, Inactive, or NoClientsInstruction
- `TypRnRy`: Case type
- `Parties`: Party names

### Sending Messages:
1. Upload a valid CSV file
2. Configure your templates (done automatically with defaults)
3. Click "Start Messaging"
4. **First time only**: Scan WhatsApp QR code when browser opens
5. Monitor progress on the dashboard

## 📝 Default Configuration

The application comes pre-configured with:

### Default Message Templates:
- **Active Clients**: Professional hearing reminders
- **Inactive Clients**: Re-engagement messages  
- **No Instructions**: Urgent instruction requests

### Default Settings:
- Notification contacts: +919876543210, +918765432109 (update these!)
- Browser profile: ShS
- Message delay: 5 seconds between messages

## ⚙️ Customization

### To Modify Default Templates:
1. Open the Configuration page in the web interface
2. Edit the message templates as needed
3. Use placeholders: `{Client}`, `{NextHearingDate}`, `{Parties}`, etc.
4. Save the configuration

### To Change Default Phone Numbers:
1. Go to Configuration page
2. Update "Primary Notification Contact" and "Secondary Notification Contact"
3. Save the configuration

### To Edit Default Settings Permanently:
1. Open `default_config.json` in a text editor
2. Modify the phone numbers and settings
3. Delete `config.json` to reset to new defaults
4. Restart the application

## 🔧 Troubleshooting

### Common Issues:

**1. "Python is not installed" error:**
- Download Python from python.org
- Reinstall with "Add to PATH" checked
- Restart command prompt and try again

**2. "Chrome not detected" warning:**
- Install Google Chrome browser
- Set Chrome as default browser (optional)

**3. WhatsApp QR Code issues:**
- Make sure you're logged out of WhatsApp Web in other tabs
- Use the same phone that has your WhatsApp account
- Scan the QR code quickly (it expires after 1 minute)

**4. Application won't start:**
- Right-click `start_windows.bat` and "Run as administrator"
- Check if port 8080 is already in use
- Restart your computer and try again

**5. CSV upload fails:**
- Check that all required columns are present
- Ensure phone numbers include country codes
- Verify dates are in YYYY-MM-DD format

### Advanced Troubleshooting:

**View Application Logs:**
- Check the `logs/webapp.log` file for detailed error messages

**Reset Configuration:**
- Delete `config.json` to restore defaults
- Delete files in `templates/` folder to reset message templates

**Clean Installation:**
- Delete the `venv` folder
- Run `install_windows.bat` again

## 📁 File Structure

```
WhatsApp-Automation/
├── app.py                      # Main application
├── start_windows.bat           # Quick start script
├── install_windows.bat         # First-time setup
├── default_config.json         # Default settings
├── default_templates/          # Default message templates
├── templates/                  # HTML templates (auto-created)
├── uploads/                    # CSV files (auto-created)
├── logs/                       # Application logs (auto-created)
├── venv/                       # Python virtual environment (auto-created)
└── requirements_windows.txt    # Python dependencies
```

## 📞 Support

### Before Asking for Help:
1. Check the troubleshooting section above
2. Look at `logs/webapp.log` for error details
3. Ensure Python and Chrome are properly installed

### Common Questions:
- **Q: Can I run this on multiple computers?**
  - A: Yes, copy the entire folder to each computer and run the setup

- **Q: How do I backup my configuration?**
  - A: Copy `config.json` and the `templates/` folder

- **Q: Can I change the port from 8080?**
  - A: Yes, edit the last line in `app.py` to change the port number

## 🔐 Security Notes

- The application runs locally on your computer
- No data is sent to external servers (except WhatsApp)
- CSV files are stored locally in the `uploads/` folder
- Chrome profile data is stored in `chrome_profile/` folder
- All templates and settings are stored locally

## 📋 Changelog

### Version 1.0
- Initial Windows release
- Default configuration support
- Automatic setup scripts
- Professional message templates